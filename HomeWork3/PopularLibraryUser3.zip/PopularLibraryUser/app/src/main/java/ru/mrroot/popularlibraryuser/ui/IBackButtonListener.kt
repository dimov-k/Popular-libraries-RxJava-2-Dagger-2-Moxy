package ru.mrroot.popularlibraryuser.ui

interface IBackButtonListener {
    fun backPressed(): Boolean
}