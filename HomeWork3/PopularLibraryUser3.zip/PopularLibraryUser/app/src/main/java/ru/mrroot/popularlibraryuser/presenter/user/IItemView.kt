package ru.mrroot.popularlibraryuser.presenter.user

interface IItemView {

    var pos: Int
}