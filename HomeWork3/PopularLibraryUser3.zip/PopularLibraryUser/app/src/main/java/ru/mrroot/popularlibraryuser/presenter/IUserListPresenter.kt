package ru.mrroot.popularlibraryuser.presenter

import ru.mrroot.popularlibraryuser.ui.IUserItemView

interface IUserListPresenter : IListPresenter<IUserItemView>